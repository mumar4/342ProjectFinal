//
//Name: Abdullah Umar, Netid: mumar4
//Name: Hamzah Quraishi, Netid: hqurai3
//Name: Abdullah Kidwai, Netid: akidwa2
//UIC
//Game342 V4
//Nov 14 2018
//

//INTERFACE REFERENCED BY ALL CHARACTERS
public interface DecisionMaker {

	public Move getMove(Character c, Place p);
	
	
}

