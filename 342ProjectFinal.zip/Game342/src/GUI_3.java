
public class GUI_3 implements UserInterface{

	@Override
	public void display(String s) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getLine() {
		// TODO Auto-generated method stub
		return null;
	}

}
