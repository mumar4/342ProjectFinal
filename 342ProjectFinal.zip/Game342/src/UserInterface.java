
public interface UserInterface {
	public void display(String s);
	public String getLine();
}
