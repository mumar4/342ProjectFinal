//
//Name: Abdullah Umar, Netid: mumar4
//Name: Hamzah Quraishi, Netid: hqurai3
//Name: Abdullah Kidwai, Netid: akidwa2
//UIC
//Game342 V4
//Nov 14 2018
//

//parent of classes that will execute() different commands
public abstract class Move {
		abstract void execute(Character c, Place p, String s);	
}

